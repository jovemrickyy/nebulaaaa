# Nebula IPTV para Android

Conteudo: `www/` (o app), `capacitor.config.json` e um workflow do GitHub que gera o APK.

## Opcao 1: gerar o APK sem Android Studio (GitHub)
1. Crie um repositorio no GitHub e envie todo o conteudo desta pasta (inclusive `.github`).
2. Abra a aba **Actions**, rode **Build APK** (ou espere o push disparar).
3. Ao terminar, baixe o artefato **nebula-apk** (zip com `app-debug.apk`).
4. Envie o APK ao celular, abra e permita "instalar apps desconhecidos".

## Opcao 2: gerar no seu computador (Node 20+, JDK 21, Android Studio)
```
npm install
npx cap add android
# em android/app/src/main/AndroidManifest.xml, na tag <application>, adicione:
#   android:usesCleartextTraffic="true"
npx cap sync android
npx cap open android      # Build > Build APK(s)
```

## Opcao 3: instalar como PWA (sem APK)
Hospede a pasta `www/` em HTTPS (GitHub Pages, Netlify), abra no Chrome do Android e use
menu > **Instalar app**. Streams em `http://` podem ser bloqueados nesse modo.

Observacoes: o APK gerado e de depuracao (assinado com chave de debug), serve para uso pessoal.
O plugin CapacitorHttp ajuda a baixar listas M3U sem bloqueio de CORS.
